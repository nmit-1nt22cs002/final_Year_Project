import cv2
import numpy as np
import os
import pandas as pd
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# ===== Helper Functions =====
def distance(v1, v2):
    return np.sqrt(((v1 - v2) ** 2).sum())

def knn(train, test, k=5):
    dist = []
    for i in range(train.shape[0]):
        ix = train[i, :-1]
        iy = train[i, -1]
        d = distance(test, ix)
        dist.append([d, iy])
    dist = sorted(dist, key=lambda x: x[0])[:k]
    labels = np.array(dist)[:, -1]
    output = np.unique(labels, return_counts=True)
    index = np.argmax(output[1])
    return output[0][index], dist[0][0]

# ===== Load Dataset =====
dataset_path = r"D:\CODE\final year project\Real-time-Face-Recognition-Project\face_dataset"
face_data = []
labels = []
names = {}
class_id = 0

for fx in os.listdir(dataset_path):
    if fx.endswith('.npy'):
        data_item = np.load(os.path.join(dataset_path, fx))
        face_data.append(data_item)
        target = class_id * np.ones((data_item.shape[0],))
        labels.append(target)
        names[class_id] = fx[:-4]
        class_id += 1

if face_data:
    face_dataset = np.concatenate(face_data, axis=0)
    face_labels = np.concatenate(labels, axis=0).reshape((-1,1))
    trainset = np.concatenate((face_dataset, face_labels), axis=1)
else:
    trainset = None

# ===== Haar Cascade =====
HAAR_PATH = r"D:\CODE\final year project\Real-time-Face-Recognition-Project\haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(HAAR_PATH)
if face_cascade.empty():
    raise IOError("❌ Could not load Haar Cascade. Check path: " + HAAR_PATH)

# ===== Tkinter UI =====
class FaceRecognitionApp:
    def __init__(self, master):
        self.master = master
        master.title("Offline Face Recognition")
        master.geometry("400x300")
        
        # Camera selection
        tk.Label(master, text="Select Camera:").pack(pady=5)
        self.cam_var = tk.StringVar(value="0")
        self.cam_dropdown = ttk.Combobox(master, textvariable=self.cam_var, values=self.get_cameras(), state="readonly")
        self.cam_dropdown.pack(pady=5)
        
        # Buttons
        tk.Button(master, text="Capture Face", command=self.capture_face).pack(pady=5)
        tk.Button(master, text="Start Recognition", command=self.start_recognition).pack(pady=5)
        tk.Button(master, text="Export Logs to Excel", command=self.export_logs).pack(pady=5)
        
        # Logs
        self.log_text = tk.Text(master, height=8)
        self.log_text.pack(pady=5)
        
        # Store recognized logs
        self.recognized_logs = []

    def get_cameras(self):
        # Detect available cameras (0 to 4)
        available = []
        for i in range(5):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                available.append(str(i))
                cap.release()
        return available if available else ["0"]

    def log(self, msg):
        self.log_text.insert(tk.END, f"{msg}\n")
        self.log_text.see(tk.END)
    
    def capture_face(self):
        cam_index = int(self.cam_var.get())
        cap = cv2.VideoCapture(cam_index)
        face_data = []
        skip = 0
        
        name = tk.simpledialog.askstring("Input", "Enter name of person:")
        if not name:
            return
        
        os.makedirs(dataset_path, exist_ok=True)
        
        self.log("Capturing face. Press 'q' to stop.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray_frame, 1.3, 5)
            if len(faces) == 0:
                cv2.imshow("Capture", frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                continue
            faces = sorted(faces, key=lambda x:x[2]*x[3], reverse=True)
            skip += 1
            for (x, y, w, h) in faces[:1]:
                offset = 5
                face_section = gray_frame[y-offset:y+h+offset, x-offset:x+w+offset]
                if face_section.size == 0:
                    continue
                face_section = cv2.resize(face_section, (100,100))
                if skip % 10 == 0:
                    face_data.append(face_section)
                cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)
            cv2.imshow("Capture", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
        
        if face_data:
            face_data = np.array(face_data).reshape(len(face_data), -1)
            np.save(os.path.join(dataset_path, name + ".npy"), face_data)
            self.log(f"✅ Dataset saved: {len(face_data)} samples for {name}")
    
    def start_recognition(self):
        if trainset is None:
            messagebox.showerror("Error", "No dataset found!")
            return
        cam_index = int(self.cam_var.get())
        cap = cv2.VideoCapture(cam_index)
        self.log(f"🎥 Recognition started on camera {cam_index}. Press 'q' to quit.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                offset = 10
                face_section = gray[y-offset:y+h+offset, x-offset:x+w+offset]
                if face_section.size == 0:
                    continue
                face_section = cv2.resize(face_section, (100,100)).flatten() / 255.0
                out_label, min_dist = knn(trainset, face_section)
                pred_name = names[int(out_label)] if min_dist < 1000 else "Unknown"
                self.recognized_logs.append([pred_name, datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
                cv2.putText(frame, pred_name, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
                cv2.rectangle(frame, (x, y), (x+w, y+h), (255,0,0), 2)
            cv2.imshow("Recognition", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
        self.log("🎥 Recognition finished.")
    
    def export_logs(self):
        if not self.recognized_logs:
            messagebox.showinfo("Info", "No logs to export.")
            return
        df = pd.DataFrame(self.recognized_logs, columns=["Name", "Timestamp"])
        filename = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files","*.xlsx")])
        if filename:
            df.to_excel(filename, index=False)
            self.log(f"✅ Logs exported to {filename}")

# ===== Run App =====
root = tk.Tk()
app = FaceRecognitionApp(root)
root.mainloop()
